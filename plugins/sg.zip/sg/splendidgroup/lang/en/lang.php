<?php return [
    'plugin' => [
        'name' => 'splendid-group',
        'description' => 'Splendid Group plugin'
    ]
];